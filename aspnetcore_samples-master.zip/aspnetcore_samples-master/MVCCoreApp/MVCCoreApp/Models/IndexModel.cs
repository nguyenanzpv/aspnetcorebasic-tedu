﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MVCCoreApp.Models
{
    public class IndexModel
    {
        public string Message { set; get; }
    }
}
