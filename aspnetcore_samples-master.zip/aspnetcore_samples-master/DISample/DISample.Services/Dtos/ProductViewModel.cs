﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DISample.Services.Dtos
{
   public  class ProductViewModel
    {
        public int Id { get; set; }

        public string Name { get; set; }
    }
}
